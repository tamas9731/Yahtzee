import random
from math import *
from tkinter import *
import tkinter as tk
from PIL import ImageTk, Image
import os,sys

root = Tk()
root.title("Yahtzee Alpha 0.1")
root.geometry("1024x768")

path = 'Texture/Yahtzee_Table.jpg'

img1 = ImageTk.PhotoImage(Image.open(path))
label1 = tk.Label(root, image = img1)
label1.place(x=0, y=0)

szurke = "lightgrey";

def dobas():

    robot = "Vesztett"
    ember = "Vesztett"

    egyesdobas = 0;
    kettesdobas = 0;
    harmasdobas = 0;
    negyesdobas = 0;
    otosdobas = 0;
    hatosdobas = 0;

    elsoo = random.randrange(1,7);
    masodikk = random.randrange(1,7);
    harmadikk = random.randrange(1,7);
    negyedikk = random.randrange(1,7);
    otodikk = random.randrange(1,7);


    
    lista = [elsoo , masodikk ,harmadikk, negyedikk, otodikk]
    rendezett = (sorted(lista, key=int) )
    sor = 0
    
    for i in range (1,5):
        if int (rendezett[i-1]) == int(rendezett[i]) -1:
            sor+=1

    kissor = 0
    for i in range (0,2):   
        if int (rendezett[i]) == int (rendezett[i+1]) -1 and int (rendezett[i+1])  == int (rendezett[i+2]) -1 and int (rendezett[i+2])  == int (rendezett[i+3]) -1  : 
            kissor = 1

    
###################################ELSŐ
    if elsoo == 1:
        egyesdobas += 1;
        
    if masodikk == 1:
        egyesdobas += 1;
        
    if harmadikk == 1:
        egyesdobas += 1;
        
    if negyedikk == 1:
        egyesdobas += 1;
        
    if otodikk == 1:
        egyesdobas += 1;
###################################MÁSODIK
    if elsoo == 2:
        kettesdobas += 1;
        
    if masodikk == 2:
        kettesdobas += 1;
        
    if harmadikk == 2:
        kettesdobas += 1;
        
    if negyedikk == 2:
        kettesdobas += 1;
        
    if otodikk == 2:
        kettesdobas += 1;
###################################HARMADIK
    if elsoo == 3:
        harmasdobas += 1;
        
    if masodikk == 3:
        harmasdobas += 1;
        
    if harmadikk == 3:
        harmasdobas += 1;
        
    if negyedikk == 3:
        harmasdobas += 1;
        
    if otodikk == 3:
        harmasdobas += 1;
###################################NEGYEDIK
    if elsoo == 4:
        negyesdobas += 1;
        
    if masodikk == 4:
        negyesdobas += 1;
        
    if harmadikk == 4:
        negyesdobas += 1;
        
    if negyedikk == 4:
        negyesdobas += 1;
        
    if otodikk == 4:
        negyesdobas += 1;
###################################ÖTÖDIK
    if elsoo == 5:
        otosdobas += 1;
        
    if masodikk == 5:
        otosdobas += 1;
        
    if harmadikk == 5:
        otosdobas += 1;
        
    if negyedikk == 5:
        otosdobas += 1;
        
    if otodikk == 5:
        otosdobas += 1;
###################################HATODIK
    if elsoo == 6:
        hatosdobas += 1;
        
    if masodikk == 6:
        hatosdobas += 1;
        
    if harmadikk == 6:
        hatosdobas += 1;
        
    if negyedikk == 6:
        hatosdobas += 1;
        
    if otodikk == 6:
        hatosdobas += 1;

    egyesdobasx = egyesdobas * 1
    kettesdobasx = kettesdobas * 2
    harmasdobasx = harmasdobas * 3
    negyesdobasx = negyesdobas * 4
    otosdobasx = otosdobas * 5
    hatosdobasx = hatosdobas * 6

    EGY = Label(root, text = elsoo, height = 1, width = 4).place(x = 660, y = 169)
    KETTO = Label(root, text = masodikk, height = 1, width = 4).place(x = 700, y = 169)
    HAROM = Label(root, text = harmadikk, height = 1, width = 4).place(x = 740, y = 169)
    NEGYEDIK = Label(root, text = negyedikk, height = 1, width = 4).place(x = 780, y = 169)
    OTODIK = Label(root, text = otodikk, height = 1, width = 4).place(x = 820, y = 169)

    DEGY = Label(root, text = egyesdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 123)
    DKETTO = Label(root, text = kettesdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 146)
    DHAROM = Label(root, text = harmasdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 169)
    DNEGYEDIK = Label(root, text = negyesdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 193)
    DOTODIK = Label(root, text = otosdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 217)
    DHATODIK = Label(root, text = hatosdobasx, background = szurke, height = 1, width = 4).place(x = 248, y = 240)

    osszeg = egyesdobasx+kettesdobasx+harmasdobasx+negyesdobasx+otosdobasx+hatosdobasx
    
    TotalScore = Label(root, text = osszeg,background = szurke, height = 1, width = 4).place(x = 248, y = 265)

    if egyesdobas == 3 or kettesdobas == 3 or harmasdobas == 3 or negyesdobas == 3 or otosdobas == 3 or hatosdobas == 3:
        Triplaaa = Label(root, text = osszeg,background = szurke, height = 1, width = 4).place(x = 248, y = 359)
        Trip = osszeg
    else:
        Triplaaa = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 359)
        Trip = 0

    if egyesdobas == 4 or kettesdobas == 4 or harmasdobas == 4 or negyesdobas == 4 or otosdobas == 4 or hatosdobas == 4:
        Quadra = Label(root, text = osszeg,background = szurke, height = 1, width = 4).place(x = 248, y = 381)
        Quad = osszeg
    else:
        Quadra = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 381)
        Quad = 0
        
    if egyesdobas == 3 and kettesdobas == 2 or egyesdobas == 2 and kettesdobas == 3 or egyesdobas == 3 and harmasdobas == 2 or egyesdobas == 2 and harmasdobas == 3 or egyesdobas == 3 and negyesdobas == 2 or egyesdobas == 2 and negyesdobas == 3 or egyesdobas == 3 and otosdobas == 2 or egyesdobas == 2 and otosdobas == 3 or egyesdobas == 3 and hatosdobas == 2 or egyesdobas == 2 and hatosdobas == 3 or kettesdobas == 3 and harmasdobas == 2 or harmasdobas == 3 and kettesdobas == 2 or kettesdobas == 3 and negyesdobas == 2 or kettesdobas == 3 and otosdobas == 2 or otosdobas == 3 and kettesdobas == 2 or kettesdobas == 3 and hatosdobas == 2 or hatosdobas == 3 and kettesdobas == 2 or harmasdobas == 3 and negyesdobas == 2 or negyesdobas == 3 and harmasdobas == 2 or harmasdobas == 3 and otosdobas == 2 or otosdobas == 3 and harmasdobas == 2 or harmasdobas == 3 and hatosdobas == 2 or hatosdobas == 3 and harmasdobas == 2 or negyesdobas == 3 and otosdobas == 2 or otosdobas == 3 and negyesdobas == 2 or negyesdobas == 3 and hatosdobas == 2 or hatosdobas == 3 and negyesdobas == 2 or otosdobas == 3 and hatosdobas == 2 or hatosdobas == 3 and otosdobas == 2:
        Fullhouse = Label(root, text = "25",background = szurke, height = 1, width = 4).place(x = 248, y = 406)
        Full = 25
    else:
        Fullhouse = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 406)
        Full = 0
        
    if egyesdobas == 5 or kettesdobas == 5 or harmasdobas == 5 or negyesdobas == 5 or otosdobas == 5 or hatosdobas == 5:
        Yahtzee = Label(root, text = "50",background = szurke, height = 1, width = 4).place(x = 248, y = 476)
        Yah = 50
    else:
        Yahtzee = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 476)
        Yah = 0

    if sor == 4:
        NagySor = Label(root, text = "40",background = szurke, height = 1, width = 4).place(x = 248, y = 452)
        Nsor = 40
        kissor = 0
        
    else:
        NagySor = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 452)
        Nsor = 0

    if kissor == 1:
        KisSor = Label(root, text = "30",background = szurke, height = 1, width = 4).place(x = 248, y = 428)
        Ksor = 30
    else:
        KisSor = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 248, y = 428)
        Ksor = 0

    

    Sansz = osszeg
    felso = osszeg
    also = Trip + Quad + Full + Yah + Sansz + Nsor + Ksor
    
    Chance = Label(root, text = Sansz,background = szurke, height = 1, width = 4).place(x = 248, y = 499)

    ALSOO = Label(root, text = also,background = szurke, height = 1, width = 4).place(x = 248, y = 570)
    FELSOO = Label(root, text = felso,background = szurke, height = 1, width = 4).place(x = 248, y = 593)

    GRANDTOTAL = felso + also
    FinalScore = Label(root, text = GRANDTOTAL,background = "red", height = 1, width = 4).place(x = 248, y = 618)

####################################################################################    
####################################################################################
####################################################################################

    regyesdobas = 0;
    rkettesdobas = 0;
    rharmasdobas = 0;
    rnegyesdobas = 0;
    rotosdobas = 0;
    rhatosdobas = 0;

    relsoo = random.randrange(1,7);
    rmasodikk = random.randrange(1,7);
    rharmadikk = random.randrange(1,7);
    rnegyedikk = random.randrange(1,7);
    rotodikk = random.randrange(1,7);


    
    rlista = [relsoo , rmasodikk ,rharmadikk, rnegyedikk, rotodikk]
    rrendezett = (sorted(rlista, key=int) )
    rsor = 0
    
    for i in range (1,5):
        if int (rrendezett[i-1]) == int(rrendezett[i]) -1:
            rsor+=1

    rkissor = 0
    for i in range (0,2):   
        if int (rrendezett[i]) == int (rrendezett[i+1]) -1 and int (rrendezett[i+1])  == int (rrendezett[i+2]) -1 and int (rrendezett[i+2])  == int (rrendezett[i+3]) -1  : 
            rkissor = 1

    
###################################ELSŐ
    if relsoo == 1:
        regyesdobas += 1;
        
    if rmasodikk == 1:
        regyesdobas += 1;
        
    if rharmadikk == 1:
        regyesdobas += 1;
        
    if rnegyedikk == 1:
        regyesdobas += 1;
        
    if rotodikk == 1:
        regyesdobas += 1;
###################################MÁSODIK
    if relsoo == 2:
        rkettesdobas += 1;
        
    if rmasodikk == 2:
        rkettesdobas += 1;
        
    if rharmadikk == 2:
        rkettesdobas += 1;
        
    if rnegyedikk == 2:
        rkettesdobas += 1;
        
    if rotodikk == 2:
        rkettesdobas += 1;
###################################HARMADIK
    if relsoo == 3:
        rharmasdobas += 1;
        
    if rmasodikk == 3:
        rharmasdobas += 1;
        
    if rharmadikk == 3:
        rharmasdobas += 1;
        
    if rnegyedikk == 3:
        rharmasdobas += 1;
        
    if rotodikk == 3:
        rharmasdobas += 1;
###################################NEGYEDIK
    if relsoo == 4:
        rnegyesdobas += 1;
        
    if rmasodikk == 4:
        rnegyesdobas += 1;
        
    if rharmadikk == 4:
        rnegyesdobas += 1;
        
    if rnegyedikk == 4:
        rnegyesdobas += 1;
        
    if rotodikk == 4:
        rnegyesdobas += 1;
###################################ÖTÖDIK
    if relsoo == 5:
        rotosdobas += 1;
        
    if rmasodikk == 5:
        rotosdobas += 1;
        
    if rharmadikk == 5:
        rotosdobas += 1;
        
    if rnegyedikk == 5:
        rotosdobas += 1;
        
    if rotodikk == 5:
        rotosdobas += 1;
###################################HATODIK
    if relsoo == 6:
        rhatosdobas += 1;
        
    if rmasodikk == 6:
        rhatosdobas += 1;
        
    if rharmadikk == 6:
        rhatosdobas += 1;
        
    if rnegyedikk == 6:
        rhatosdobas += 1;
        
    if rotodikk == 6:
        rhatosdobas += 1;

    regyesdobasx = regyesdobas * 1
    rkettesdobasx = rkettesdobas * 2
    rharmasdobasx = rharmasdobas * 3
    rnegyesdobasx = rnegyesdobas * 4
    rotosdobasx = rotosdobas * 5
    rhatosdobasx = rhatosdobas * 6

    rEGY = Label(root, text = relsoo, height = 1, width = 4).place(x = 660, y = 200)
    rKETTO = Label(root, text = rmasodikk, height = 1, width = 4).place(x = 700, y = 200)
    rHAROM = Label(root, text = rharmadikk, height = 1, width = 4).place(x = 740, y = 200)
    rNEGYEDIK = Label(root, text = rnegyedikk, height = 1, width = 4).place(x = 780, y = 200)
    rOTODIK = Label(root, text = rotodikk, height = 1, width = 4).place(x = 820, y = 200)

    rDEGY = Label(root, text = regyesdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 123)
    rDKETTO = Label(root, text = rkettesdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 146)
    rDHAROM = Label(root, text = rharmasdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 169)
    rDNEGYEDIK = Label(root, text = rnegyesdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 193)
    rDOTODIK = Label(root, text = rotosdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 217)
    rDHATODIK = Label(root, text = rhatosdobasx, background = szurke, height = 1, width = 4).place(x = 483, y = 240)

    rosszeg = regyesdobasx+rkettesdobasx+rharmasdobasx+rnegyesdobasx+rotosdobasx+rhatosdobasx
    
    rTotalScore = Label(root, text = rosszeg,background = szurke, height = 1, width = 4).place(x = 483, y = 265)

    if regyesdobas == 3 or rkettesdobas == 3 or rharmasdobas == 3 or rnegyesdobas == 3 or rotosdobas == 3 or rhatosdobas == 3:
        rTriplaaa = Label(root, text = rosszeg,background = szurke, height = 1, width = 4).place(x = 483, y = 359)
        rTrip = rosszeg
    else:
        rTriplaaa = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 359)
        rTrip = 0

    if regyesdobas == 4 or rkettesdobas == 4 or rharmasdobas == 4 or rnegyesdobas == 4 or rotosdobas == 4 or rhatosdobas == 4:
        rQuadra = Label(root, text = rosszeg,background = szurke, height = 1, width = 4).place(x = 483, y = 381)
        rQuad = osszeg
    else:
        rQuadra = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 381)
        rQuad = 0
        
    if regyesdobas == 3 and rkettesdobas == 2 or regyesdobas == 2 and rkettesdobas == 3 or regyesdobas == 3 and rharmasdobas == 2 or regyesdobas == 2 and rharmasdobas == 3 or regyesdobas == 3 and rnegyesdobas == 2 or regyesdobas == 2 and rnegyesdobas == 3 or regyesdobas == 3 and rotosdobas == 2 or regyesdobas == 2 and rotosdobas == 3 or regyesdobas == 3 and rhatosdobas == 2 or regyesdobas == 2 and rhatosdobas == 3 or rkettesdobas == 3 and rharmasdobas == 2 or rharmasdobas == 3 and rkettesdobas == 2 or rkettesdobas == 3 and rnegyesdobas == 2 or rkettesdobas == 3 and rotosdobas == 2 or rotosdobas == 3 and rkettesdobas == 2 or rkettesdobas == 3 and rhatosdobas == 2 or rhatosdobas == 3 and rkettesdobas == 2 or rharmasdobas == 3 and rnegyesdobas == 2 or rnegyesdobas == 3 and rharmasdobas == 2 or rharmasdobas == 3 and rotosdobas == 2 or rotosdobas == 3 and rharmasdobas == 2 or rharmasdobas == 3 and rhatosdobas == 2 or rhatosdobas == 3 and rharmasdobas == 2 or rnegyesdobas == 3 and rotosdobas == 2 or rotosdobas == 3 and rnegyesdobas == 2 or rnegyesdobas == 3 and rhatosdobas == 2 or rhatosdobas == 3 and rnegyesdobas == 2 or rotosdobas == 3 and rhatosdobas == 2 or rhatosdobas == 3 and rotosdobas == 2:
        rFullhouse = Label(root, text = "25",background = szurke, height = 1, width = 4).place(x = 483, y = 406)
        rFull = 25
    else:
        rFullhouse = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 406)
        rFull = 0
        
    if regyesdobas == 5 or rkettesdobas == 5 or rharmasdobas == 5 or rnegyesdobas == 5 or rotosdobas == 5 or rhatosdobas == 5:
        rYahtzee = Label(root, text = "50",background = szurke, height = 1, width = 4).place(x = 483, y = 476)
        rYah = 50
    else:
        rYahtzee = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 476)
        rYah = 0

    if rsor == 4:
        rNagySor = Label(root, text = "40",background = szurke, height = 1, width = 4).place(x = 483, y = 452)
        rNsor = 40
        rkissor = 0
        
    else:
        rNagySor = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 452)
        rNsor = 0

    if rkissor == 1:
        rKisSor = Label(root, text = "30",background = szurke, height = 1, width = 4).place(x = 483, y = 428)
        rKsor = 30
    else:
        rKisSor = Label(root, text = "-",background = szurke, height = 1, width = 4).place(x = 483, y = 428)
        rKsor = 0

    rSansz = rosszeg
    rfelso = rosszeg
    ralso = rTrip + rQuad + rFull + rYah + rSansz + rNsor + rKsor
    
    rChance = Label(root, text = rSansz,background = szurke, height = 1, width = 4).place(x = 483, y = 499)

    rALSOO = Label(root, text = ralso,background = szurke, height = 1, width = 4).place(x = 483, y = 570)
    rFELSOO = Label(root, text = rfelso,background = szurke, height = 1, width = 4).place(x = 483, y = 593)

    rGRANDTOTAL = rfelso + ralso
    rFinalScore = Label(root, text = rGRANDTOTAL,background = "red", height = 1, width = 4).place(x = 483, y = 618)

    if rGRANDTOTAL < GRANDTOTAL:
        robot = "Nyert"
    else:
        ember = "Nyert"

    x = Label(root, text = robot, height = 1, width = 6).place(x = 710, y = 400)

    y = Label(root, text = ember, height = 1, width = 6).place(x = 710, y = 430)
    
def elokeszites():
    Dobas = Button(root, text = "Dobás", height = 1, width = 9, command = dobas).place(x = 720, y = 30)
    name = msg_1.get()

    NEV = Label(root, text = name,background = szurke, height = 1, width = 24).place(x = 340, y = 50)

    mlabel2 = Label(root, text = name ).place(x = 650, y = 400)
    mlabel4 = Label(root, text = name ).place(x = 600, y = 169)
    
    mlabel3 = Label(root, text = "Robot ").place(x = 650, y = 430)
    mlabel3 = Label(root, text = "Robot ").place(x = 600, y = 200)



    
msg_1 = StringVar()
    
mtext1 = Entry(root, textvariable=msg_1, width=25).place(x=690, y=300)
    
mlabel1 = Label(root, text= "Név: ").place(x = 650,y = 300)
    
Start = Button(root, text = "Start", height = 1, width = 9, command = elokeszites).place(x = 720, y = 340)


root.mainloop()
